// trolling function
function reg_click() {
    for (var i = 0; i < 3; i++) {}
    alert("YOU HAVE BEEN HACKED!!!!!!!!!")
}